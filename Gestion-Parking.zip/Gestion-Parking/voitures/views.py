from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse

from .models import Voiture
from .forms import VoitureForm

# Create your views here.
def index(request):
  return render(request, 'voitures/index.html', {
    'voitures': Voiture.objects.all()
  })

def view_voiture(request, id):
  voiture = Voiture.objects.get(pk=id)
  return HttpResponseRedirect(reverse('index'))

def add(request):
  if request.method == 'POST':
    form = VoitureForm(request.POST)
    if form.is_valid():
            new_matricule = form.cleaned_data['matricule']
            new_marque = form.cleaned_data['marque']
            new_modele = form.cleaned_data['modele']
            new_Couleur = form.cleaned_data['Couleur']
            new_annee = form.cleaned_data['annee']
            new_prix = form.cleaned_data['prix']

            new_voiture = Voiture(
                matricule= new_matricule,
                marque =new_marque,
                modele= new_modele,
                Couleur= new_Couleur,
                annee=new_annee,
                prix= new_prix
            )
            new_voiture.save()
            return render(request, 'voitures/add.html',
                          {'form':VoitureForm(),'success':True})
  else:
            form=VoitureForm()
  return render(request,'voitures/add.html',{'form': VoitureForm()})

def edit(request, id):
  if request.method == 'POST':
    voiture = Voiture.objects.get(pk=id)
    form = VoitureForm(request.POST, instance=voiture)
    if form.is_valid():
      form.save()
      return render(request, 'voitures/edit.html', {
        'form': form,
        'success': True
      })
  else:
    voiture = Voiture.objects.get(pk=id)
    form = VoitureForm(instance=voiture)
  return render(request, 'voitures/edit.html', {
    'form': form
  })

def delete(request, id):
  if request.method == 'POST':
    voiture = Voiture.objects.get(pk=id)
    voiture.delete()
  return HttpResponseRedirect(reverse('index'))