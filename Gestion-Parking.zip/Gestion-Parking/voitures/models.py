from django.db import models

# Create your models here.
class Voiture(models.Model):
    matricule =models.CharField(max_length=100)
    marque =models.CharField(max_length=100)
    modele =models.CharField(max_length=100)
    Couleur =models.CharField(max_length=100)
    annee =models.PositiveIntegerField()
    prix =models.PositiveIntegerField()

def __str__(self):
    return f'Voiture: {self.marque} {self.modele}'