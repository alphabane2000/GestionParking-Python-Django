from django.contrib import admin
from .models import Voiture
# Register your models here.
admin.site.register(Voiture)