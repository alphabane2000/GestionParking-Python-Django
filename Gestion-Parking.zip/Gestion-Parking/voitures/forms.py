from django import forms 
from .models import Voiture

class VoitureForm(forms.ModelForm):
    class Meta:
        model= Voiture
        fields=['matricule','marque','modele','Couleur','annee','prix']
        labels={
          'matricule': 'Matricule',
          'marque' : 'Marque',
          'modele' : 'Modèle',
          'Couleur' : 'Couleur',
          'annee': 'Année',
          'prix': 'Prix'
          
        }

        widgets= {
            'matricule': forms.TextInput(attrs={'class': 'form-control'}),
            'marque' : forms.TextInput(attrs={'class': 'form-control'}),
            'modele' : forms.TextInput(attrs={'class': 'form-control'}),
            'Couleur' :forms.TextInput(attrs={'class': 'form-control'}),
            'annee': forms.NumberInput(attrs={'class': 'form-control'}),
            'prix': forms.NumberInput(attrs={'class': 'form-control'}),
        
        }
        